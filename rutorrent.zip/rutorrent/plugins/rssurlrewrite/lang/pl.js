﻿/*
 * PLUGIN RSSURLREWRITE
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.rssNewRule		= "Nowa reguła";
 theUILang.mnu_rssurlrewrite	= "Adresy RSS";
 theUILang.rssRulesManager	= "Menedżer adresów RSS";
 theUILang.rssAddRule		= "Dodaj";
 theUILang.rssDelRule		= "Usuń";
 theUILang.rssCheckRule 	= "?";
 theUILang.rssRulesLegend	= "Ustawienia reguły";
 theUILang.rssSrcHref		= "Jeśli adres pobierania torrenta pasuje do wzorca";
 theUILang.rssSrcGuid		= "Jeśli adres opisu torrenta pasuje do wzorca";
 theUILang.rssDstHref		= "wtedy zastąp adres pobierania tym";
 theUILang.rssDstGuid		= "wtedy zastąp adres opisu tym";
 theUILang.rssRulesDebug	= "Sprawdź regułę";
 theUILang.rssTestString	= "Test";
 theUILang.rssTestResult	= "Wynik";
 theUILang.rssURLInfo		= "Adresy";
 theUILang.rssURLGUID		= "Adres opisu torrenta";
 theUILang.rssURLHref		= "Adres pobierania torrenta";
 theUILang.rssPatternError	= "Błędny wzorzec";
 theUILang.rssStatus		= "RSS";

thePlugins.get("rssurlrewrite").langLoaded();