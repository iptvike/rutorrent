﻿/*
 * PLUGIN RSSURLREWRITE
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.rssNewRule		= "Nueva regla";
 theUILang.mnu_rssurlrewrite	= "URL de reemplazo en RSS";
 theUILang.rssRulesManager	= "Administrador de Reglas";
 theUILang.rssAddRule		= "Agregar";
 theUILang.rssDelRule		= "Borrar";
 theUILang.rssCheckRule 	= "?";
 theUILang.rssRulesLegend	= "Configuración de reglas";
 theUILang.rssSrcHref		= "Si la URL de descarga del torrent conicide con el patrón";
 theUILang.rssSrcGuid		= "Si la URL de descripción del torrent conicide con el patrón";
 theUILang.rssDstHref		= "reemplazar la URL de descarga del torrent con";
 theUILang.rssDstGuid		= "reemplazar la URL de descripción del torrent con";
 theUILang.rssRulesDebug	= "Debug de reglas";
 theUILang.rssTestString	= "Test";
 theUILang.rssTestResult	= "Resultado";
 theUILang.rssURLInfo		= "URL de info";
 theUILang.rssURLGUID		= "URL de descripción";
 theUILang.rssURLHref		= "URL de descarga";
 theUILang.rssPatternError	= "Error en el patrón.";
 theUILang.rssStatus		= "RSS";

thePlugins.get("rssurlrewrite").langLoaded();