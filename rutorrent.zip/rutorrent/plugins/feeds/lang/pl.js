﻿/*
 * PLUGIN FEEDS
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.feedAll		= "Wszystkie torrenty";
 theUILang.feedCompleted	= "Ukończone torrenty";
 theUILang.feedDownloading	= "Pobierane torrenty";
 theUILang.feedActive		= "Aktywne torrenty";
 theUILang.feedInactive 	= "Nieaktywne torrenty";
 theUILang.feedError		= "Błędne torrenty";

thePlugins.get("feeds").langLoaded();