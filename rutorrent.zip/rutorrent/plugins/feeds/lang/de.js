﻿/*
 * PLUGIN FEEDS
 *
 * German language file.
 *
 * Author: 
 */

 theUILang.feedAll		= "All torrents";
 theUILang.feedCompleted	= "Completed torrents";
 theUILang.feedDownloading	= "Downloading torrents";
 theUILang.feedActive		= "Active torrents";
 theUILang.feedInactive 	= "Inactive torrents";
 theUILang.feedError		= "Error torrents";

thePlugins.get("feeds").langLoaded();