﻿/*
 * PLUGIN FEEDS
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.feedAll		= "모든 토렌트";
 theUILang.feedCompleted	= "완료된 토렌트";
 theUILang.feedDownloading	= "다운로드 중인 토렌트";
 theUILang.feedActive		= "활성화된 토렌트";
 theUILang.feedInactive 	= "비활성화된 토렌트";
 theUILang.feedError		= "오류 발생 토렌트";

thePlugins.get("feeds").langLoaded();
