﻿/*
 * PLUGIN FEEDS
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.feedAll		= "Alle torrenter";
 theUILang.feedCompleted	= "Fullførte torrenter";
 theUILang.feedDownloading	= "Nedlastende torrenter";
 theUILang.feedActive		= "Aktive torrenter";
 theUILang.feedInactive 	= "Inaktive torrenter";
 theUILang.feedError		= "Feil-torrenter";

thePlugins.get("feeds").langLoaded();