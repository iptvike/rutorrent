﻿/*
 * PLUGIN FEEDS
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.feedAll		= "Alla torrenter";
 theUILang.feedCompleted	= "Färdiga torrenter";
 theUILang.feedDownloading	= "Nedladdande torrenter";
 theUILang.feedActive		= "Aktiva torrenter";
 theUILang.feedInactive 	= "Inaktiva torrenter";
 theUILang.feedError		= "Fel-torrenter";

thePlugins.get("feeds").langLoaded();
