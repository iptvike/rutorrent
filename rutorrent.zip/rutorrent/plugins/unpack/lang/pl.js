﻿/*
 * PLUGIN UNPACK
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.unpack		= "Rozpakuj";
 theUILang.unpackPath		= "Rozpakuj do (puste aby rozpakować do folderu torrenta)";
 theUILang.unzipNotFound	= "Wtyczka unpack: Użytkownik rTorrent nie ma dostępu do programu 'unzip'.";
 theUILang.unrarNotFound	= "Wtyczka unpack: Użytkownik rTorrent nie ma dostępu do programu 'unrar'.";
 theUILang.unpackEnabled	= "Rozpakuj jeśli etykieta torrenta pasuje do wzorca";
 theUILang.unpackTorrents	= "Dodaj do ścieżki podczas rozpakowywania";
 theUILang.unpackAddLabel	= "Etykiete torrenta";
 theUILang.unpackAddName	= "Nazwe torrenta";

thePlugins.get("unpack").langLoaded();
