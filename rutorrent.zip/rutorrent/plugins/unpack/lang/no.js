﻿/*
 * PLUGIN UNPACK
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.unpack		= "Pakk ut";
 theUILang.unpackPath		= "Pakk ut til (la stå tom for torrentens nåværende mappe)";
 theUILang.unzipNotFound	= "Unpack plugin: rTorrent-brukeren får ikke tilgang til 'unzip'-programmet.";
 theUILang.unrarNotFound	= "Unpack plugin: rTorrent-brukeren får ikke tilgang til 'unrar'-programmet.";
 theUILang.unpackEnabled	= "Aktiver automatisk utpakking hvis torrentens etikett matcher filter";
 theUILang.unpackTorrents	= "Tilføy til filstinavnet ved utpakking av torrentdata";
 theUILang.unpackAddLabel	= "Torrentetikett";
 theUILang.unpackAddName	= "Torrentnavn";

thePlugins.get("unpack").langLoaded();