﻿/*
 * PLUGIN LookAt
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.lookAtDesc = "Find at (Format: name|url)";
 theUILang.lookAt = "Find at";

thePlugins.get("lookat").langLoaded();