﻿/*
 * PLUGIN LookAt
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.lookAtDesc = "다음에서 찾기 (형식: 이름|url)";
 theUILang.lookAt = "다음에서 찾기";

thePlugins.get("lookat").langLoaded();
