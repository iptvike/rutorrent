﻿/*
 * PLUGIN LookAt
 *
 * Polish language file.
 *
 * Author:
 */

 theUILang.lookAtDesc = "Znajdź w (Format: nazwa|url)";
 theUILang.lookAt = "Znajdź w";

thePlugins.get("lookat").langLoaded();
