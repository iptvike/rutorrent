﻿/*
 * PLUGIN LookAt
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.lookAtDesc = "Εύρεση στο (Μορφή: όνομα|url)";
 theUILang.lookAt = "Εύρεση στο";

thePlugins.get("lookat").langLoaded();