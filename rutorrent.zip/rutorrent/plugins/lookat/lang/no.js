﻿/*
 * PLUGIN LookAt
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.lookAtDesc = "Finn på (Format: navn|lenke)";
 theUILang.lookAt = "Finn på";

thePlugins.get("lookat").langLoaded();