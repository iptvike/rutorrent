<?php

$partsToRemove = "([\.-](1080p|720p|x264|WEBDL|WebRip|VHSRip|CamRip|TS|DVDSCR|BluRay|BRRip|BDRemux|".
	"TC|TVRip|SATRip|DVDRip|HDTVRip|BDRip|DVD5|DVD9|MP3|HDRip|".
	"MP4|WEB-DL|Web-Rip|VHS-Rip|Cam-Rip|DVD-SCR|TV-Rip|Blu-Ray|BR-Rip|HD-Rip|BD-Remux|SCR|".
	"SAT-Rip|DVD-Rip|HDTV-Rip|BD-Rip|DVD-5|DVD-9|HDTV|MULTi8|GoG|XviD|EXTENDED|BLURAY|BLU-RAY|DTS|DD5.1)|-[^-]+$)";
