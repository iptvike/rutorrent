﻿/*
 * PLUGIN FILEDROP
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "filedrop 플러그인: 브라우저가 HTML5 파일 업로드를 지원하지 않습니다. 플러그인이 비활성화되었습니다.";
 theUILang.tooManyFiles 	= "filedrop 플러그인: 파일이 너무 많습니다. 최대 개수 <= ";
 theUILang.fileTooLarge 	= "크기가 너무 큽니다. 다음 크기까지만 업로드해주세요: ";

thePlugins.get("filedrop").langLoaded();
