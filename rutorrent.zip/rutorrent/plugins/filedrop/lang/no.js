﻿/*
 * PLUGIN FILEDROP
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Din nettleser støtter ikke HTML5 filopplastinger. Pluginen har blitt deaktivert.";
 theUILang.tooManyFiles 	= "Plugin filedrop: For mange filer. Må være <= ";
 theUILang.fileTooLarge 	= "er for stor. Vennligst last opp filer opp til";

thePlugins.get("filedrop").langLoaded();