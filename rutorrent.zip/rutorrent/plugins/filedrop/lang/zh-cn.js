﻿/*
 * PLUGIN FILEDROP
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.doesntSupportHTML5	= "Filedrop 插件: 你的浏览器不支持 HTML5 文件上传. 插件已被禁用.";
 theUILang.tooManyFiles 	= "Filedrop 插件: 文件太多了. 必须 <= ";
 theUILang.fileTooLarge 	= "太大了. 请最多上传";

thePlugins.get("filedrop").langLoaded();
