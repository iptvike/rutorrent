﻿/*
 * PLUGIN FILEDROP
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Ihr Browser unterstützt keine HTML5-Uploads. Plugin wurde deaktiviert.";
 theUILang.tooManyFiles 	= "Plugin filedrop: Zu viele Dateien. Maximal <= ";
 theUILang.fileTooLarge 	= "ist zu groß. Bitte lade Dateien bis zu";

thePlugins.get("filedrop").langLoaded();