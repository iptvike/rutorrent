﻿/*
 * PLUGIN FILEDROP
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Wtyczka filedrop: Twoja przeglądarka nie obsługuje wysyłania plików HTML5. Wtyczka została wyłączona.";
 theUILang.tooManyFiles 	= "Wtyczka filedrop: Za dużo plików. Musi być <= ";
 theUILang.fileTooLarge 	= "jest za duży. Proszę wysłać pliki maksymalnie do";

thePlugins.get("filedrop").langLoaded();
