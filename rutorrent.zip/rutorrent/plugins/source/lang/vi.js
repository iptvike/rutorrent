﻿/*
 * PLUGIN SOURCE
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.getSource		= "Lấy tập tin .torrent";
 theUILang.cantFindTorrent	= "Không tìm thấy tập tin torrent gốc đang tải.";

thePlugins.get("source").langLoaded();