﻿/*
 * PLUGIN SOURCE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.getSource		= "获取 .torrent";
 theUILang.cantFindTorrent	= "这个下载的 torrent 源文件未找到.";

thePlugins.get("source").langLoaded();
