﻿/*
 * PLUGIN SOURCE
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.getSource		= ".torrent 얻기";
 theUILang.cantFindTorrent	= "이 다운로드 항목에 해당하는 원본 토렌트 파일을 찾지 못했습니다.";

thePlugins.get("source").langLoaded();
