﻿/*
 * PLUGIN SOURCE
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.getSource		= "Hent .torrent-fil";
 theUILang.cantFindTorrent	= "Torrentfilen for denne nedlastingen ble ikke funnet.";

thePlugins.get("source").langLoaded();