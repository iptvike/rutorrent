﻿/*
 * PLUGIN TRAFFIC
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.traf 	= "Traffic";
 theUILang.perDay	= "Pro Tag";
 theUILang.perMonth 	= "Pro Monat";
 theUILang.perYear 	= "Pro Jahr";
 theUILang.allTrackers	= "Alle Tracker";
 theUILang.ClearButton	= "Löschen";
 theUILang.ClearQuest 	= "Statistik des ausgewählten Trackers wirklich löschen?";
 theUILang.selectedTorrent	= "Ausgewählte(r) Torrent(s)";
 theUILang.ratioDay	= "Ratio/Tag";
 theUILang.ratioWeek	= "Ratio/Woche";
 theUILang.ratioMonth	= "Ratio/Monat";
