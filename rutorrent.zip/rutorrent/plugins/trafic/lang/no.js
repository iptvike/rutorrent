﻿/*
 * PLUGIN TRAFFIC
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.traf 		= "Trafikk";
 theUILang.perDay		= "Per dag";
 theUILang.perMonth		= "Per måned";
 theUILang.perYear		= "Per år";
 theUILang.allTrackers		= "Alle trackere";
 theUILang.ClearButton		= "Tøm";
 theUILang.ClearQuest		= "Vil du virkelig slette statistikken for utvalgt tracker(e)?";
 theUILang.selectedTorrent	= "Utvalgt tracker(e)";
 theUILang.ratioDay		= "Ratio/dag";
 theUILang.ratioWeek		= "Ratio/uke";
 theUILang.ratioMonth		= "Ratio/måned";
