﻿/*
 * PLUGIN _TASK
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "运行中...";
 theUILang.tskCommandDone	= "已完成.";
 theUILang.tskConsole		= "控制台";
 theUILang.tskErrors		= "诊断";
 theUILang.tskBackground	= "隐藏";
 theUILang.tskStart		= "已开始";
 theUILang.tskFinish		= "已完成";
 theUILang.tskElapsed		= "已用时间";
 theUILang.tskPlugin		= "插件";
 theUILang.tskDeletePrompt	= "你真的要删除选中的任务吗?";
 theUILang.tskDelete		= "删除任务";
 theUILang.tskActivate		= "激活";
 theUILang.tskRemove		= "移除";
 theUILang.tskRefresh		= "刷新";
 theUILang.tskRunning		= "运行中";
 theUILang.tskArg		= "参数";
 theUILang.tskTasks		= "任务";

thePlugins.get("_task").langLoaded();
