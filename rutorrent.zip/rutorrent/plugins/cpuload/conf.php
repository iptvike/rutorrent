<?php

$processorsCount = null; // Count of processors. If null - autodetect (linux only)
