﻿/*
 * PLUGIN ERASEDATA
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.Rem_torrents_content_prompt		= "정말 선택한 토렌트를 제거할까요? 경고: 토렌트 내용물이 함께 삭제됩니다.";
 theUILang.Delete_data_with_path		= "경로 삭제";
 theUILang.Rem_torrents_with_path_prompt	= "정말 선택한 토렌트를 제거할까요? 경고: 토렌트의 현재 디렉토리에 속한 모든 파일이 함께 삭제됩니다.";

thePlugins.get("erasedata").langLoaded();
