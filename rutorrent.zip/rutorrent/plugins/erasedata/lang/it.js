﻿/*
 * PLUGIN ERASEDATA
 *
 * Italian language file.
 *
 * Author: 
 */

 theUILang.Rem_torrents_content_prompt		= "Do you really want to remove the selected torrent(s)? WARNING: This will delete torrent's content.";
 theUILang.Delete_data_with_path		= "Delete Path";
 theUILang.Rem_torrents_with_path_prompt	= "Do you really want to remove the selected torrent(s)? WARNING: This will delete all files in this torrent's current directory.";

thePlugins.get("erasedata").langLoaded();