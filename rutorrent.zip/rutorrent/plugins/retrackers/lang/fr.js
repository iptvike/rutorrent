﻿/*
 * PLUGIN RETRACKERS
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Ajouter des URL d'annonces";
 theUILang.retrackersDel	= "Retirer des URL d'annonces";
 theUILang.dontAddToPrivate	= "Ne pas toucher aux torrents privés";
 theUILang.addToBegin		= "Ajouter les URL d'annonces au début de la liste";

thePlugins.get("retrackers").langLoaded();
