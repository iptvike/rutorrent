﻿/*
 * PLUGIN RETRACKERS
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Dodaj adresy trackerów";
 theUILang.retrackersDel	= "Usuń adresy trackerów";
 theUILang.dontAddToPrivate	= "Nie modyfikuj prywatnych torrentów";
 theUILang.addToBegin		= "Dodaj adresy na początku listy";

thePlugins.get("retrackers").langLoaded();
