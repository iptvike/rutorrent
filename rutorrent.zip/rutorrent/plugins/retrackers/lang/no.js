﻿/*
 * PLUGIN RETRACKERS
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Legg til Announce-lenker";
 theUILang.retrackersDel	= "Fjern Announce-lenker";
 theUILang.dontAddToPrivate	= "Ikke rør private torrenter";
 theUILang.addToBegin		= "Legg til announce-lenker til begynnelsen av listen med trackere";

thePlugins.get("retrackers").langLoaded();